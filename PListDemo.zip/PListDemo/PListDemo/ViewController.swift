
import UIKit

class ViewController: UIViewController
{

    @IBAction func btnInsert(_ sender: Any)
    {
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        
        let strpath = arr[0] 
        let fullpath = strpath.appending("/Profile.plist")
        print(fullpath)
        let fmg = FileManager()
        if !fmg.fileExists(atPath: fullpath)
        {
            let dic = ["name":"tops","address":"surat"]
            let finaldic = NSDictionary(dictionary: dic)
            finaldic.write(toFile: fullpath, atomically: true)
        }
    
    }
    
    
    @IBAction func btnDisplay(_ sender: Any)
    {
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let strpath = arr[0]
        let fullpath = strpath.appending("/Profile.plist")
        print(fullpath)
        let fmg = FileManager()
        if fmg.fileExists(atPath: fullpath)
        {
            let dic = NSDictionary(contentsOfFile: fullpath)
            print(dic ?? "Nothing")
        }
    }
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
    }
    


    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }


}

